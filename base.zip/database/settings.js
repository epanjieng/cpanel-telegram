const settings = {
  token: '-',
  adminId: '8002627956', 
  pp: 'https://files.catbox.moe/rjlonn.jpeg',
urladmin: 'https://t.me/xsatten',
    //SERVER 1
  domain: 'https://xsatluddosmaklumati.resellergaming-official.my.id', // domain
  plta: 'ptla_vVoG4JFkMQRCdvQPje5nH253tkPT7Ca2QHIQMJLximm', //  plta yang sesuai
  pltc: 'ptlc_uflrmGkw2X30leUpRhQ5WOiK0r1hqRTCTqhxzhzbQIr', // pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;